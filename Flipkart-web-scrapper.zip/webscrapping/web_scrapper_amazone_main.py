import web_scrapper_amazon
# scraper = web_scrapper_amazon.amazon_review_scraper(url, start_page, end_page, time)
scraper = web_scrapper_amazon.amazon_review_scraper("https://www.amazon.com/Milkman-Novel-Anna-Burns/product-reviews/1644450003/ref=cm_cr_dp_d_show_all_btm?ie=UTF8&reviewerType=all_reviews&pageNumber=1", 1, 1, 100);
# scraper = web_scrapper_amazon.amazon_review_scraper("https://www.amazon.com/Milkman-Novel-Anna-Burns/product-reviews/1644450003/ref=cm_cr_arp_d_paging_btm_next_2?ie=UTF8&reviewerType=all_reviews&pageNumber=1", 1, 5, 100);
scraper.scrape()
scraper.write_csv('milkman1')