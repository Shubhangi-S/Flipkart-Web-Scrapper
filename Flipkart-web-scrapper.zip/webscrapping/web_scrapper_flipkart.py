import urllib3
from bs4 import BeautifulSoup
import ssl
import random
import time
from random import randint
import csv


class amazon_review_scraper:
    # Ignore SSL certificate errors
    ssl._create_default_https_context = ssl._create_unverified_context

    csv_data = []

    csv_head = ["Rating", "Title", "Name", "Verified Purchase", "Body", "Helpful Votes"]

    def __init__(self, url, start_page, end_page, time_upper_limit):
        self.url = url
        self.set_url()
        self.start_page = int(start_page)
        self.end_page = int(end_page)
        self.time_upper_limit = time_upper_limit

    def set_sleep_timer(self):
        sleep_time = randint(0, int(self.time_upper_limit))
        print("\nSleeping for " + str(sleep_time) + " seconds.")
        time.sleep(sleep_time)

    def set_url(self):
        # removing pageNumber parameter if it exists in the url
        url = self.url.split("&page")
        if len(url) > 1:
            self.url = url[0]
        else:
            self.url = url

        print(url)

    def set_start_page(self, start_page):
        url = self.url + "&page=" + str(start_page)
        return url

    def build_rating(self, review):
        try:
            review = review.find("div", attrs={"class": "hGSR34 E_uFuv"}).get_text()
            print('rating' + str(review))
        except:
            return "None"


        return str(review);

    def build_title(self, review):

        review = review.find("p", attrs={"class": "_2xg6Ul"}).get_text()
        print('title' + str(review))

        return str(review)
    def build_date(self, review):

        review = review.find("p", attrs={"class": "_3LYOAd"}).get_text()
        print(review)
        return str(review)

    def build_verified_purchase(self, review):
        # Yes = purchased, No = not purchased
        try:

            review = review.find("p", attrs={"class": "_19inI8"}).get_text()
            if (str(review).__eq__('Yes')):
                return "Yes";
            else:
                return "No"

        except:
            return "No"

    def build_body(self, review):

        review = review.find("div", attrs={"class": "qwjRop"}).get_text()
        print(review)
        return str(review)

    def build_votes(self, review):
        try:
            review = review.find_all("span", attrs={"class": "_1_BQL8"})[0].get_text()
            print(review)
            if review[0] == "One":
                return "1"
            else:
                return str(review[0])
        except:
            return "0"

    def scrape(self):

        start_page = self.start_page
        end_page = self.end_page

        if end_page < start_page:
            print("Start page cannot be greater than end page. Please try again.")
            exit()

        self.csv_data.append(self.csv_head)

        while start_page <= end_page:

            try:
                url = self.set_start_page(start_page)
            except:
                print("URL entered is wrong. Please try again with the right URL.")
                exit()

            # Sleep because Amazon might block your IP if there are too many requests every second
            self.set_sleep_timer()

            print("Scraping page " + str(start_page) + ".")

            # Amazon blocks requests that don't come from browser. Hence need to mention user-agent
            user_agent = 'Mozilla/5.0'
            # user_agent= 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36',

            headers = {'User-Agent': user_agent}

            values = {}

            # data = urllib3.parse.urlencode(values).encode('utf-8')
            # import requests
            import requests

            cookies = {
                '_ga': 'GA1.2.1448404132.1578048795',
                '_gid': 'GA1.2.1462970206.1578371103',
                '_gat': '1',
            }

            headers = {
                'Connection': 'keep-alive',
                'Cache-Control': 'max-age=0',
                'DNT': '1',
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36',
                'Sec-Fetch-User': '?1',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'Sec-Fetch-Site': 'cross-site',
                'Sec-Fetch-Mode': 'navigate',
                'Accept-Encoding': 'gzip, deflate, br',
                'Accept-Language': 'en-US,en;q=0.9',
                'If-None-Match': 'W/^\\^5dd9ca33-15c5^\\^',
                'If-Modified-Since': 'Sun, 24 Nov 2019 00:09:23 GMT',
            }

            # response = requests.get('https://curl.trillworks.com/', headers=headers, cookies=cookies)

            r = requests.get(url,headers=headers, cookies=cookies)
            soup = BeautifulSoup(r.content, "lxml")
            # soup = BeautifulSoup(html, 'html.parser')
            # print(soup.get_text)
            reviews = soup.find_all("div", attrs={"class": "_1PBCrt"})
            print('------')
            # print(reviews)
            print('*****')
            for review in reviews:
                csv_body = []

                # Star Rating
                rating = self.build_rating(review)
                print(rating)
                csv_body.append(rating)

                # Title
                title = self.build_title(review)
                print(title)
                csv_body.append(title)

                # Date
                date = self.build_date(review)
                csv_body.append(date)

                # Verified Purchase
                verified_purchase = self.build_verified_purchase(review)
                csv_body.append(verified_purchase)

                # Body
                body = self.build_body(review)
                csv_body.append(body)

                # Helpful Votes
                votes = self.build_votes(review)
                csv_body.append(votes)

                self.csv_data.append(csv_body)

            start_page += 1

    def write_csv(self, file_name):

        print("\nWriting to file.\n")

        with open((file_name + '.csv'), 'a') as csv_file:
            writer = csv.writer(csv_file, delimiter=',')
            writer.writerows(self.csv_data)