import web_scrapper_flipkart
# scraper = web_scrapper_amazon.amazon_review_scraper(url, start_page, end_page, time)
# scraper = web_scrapper_flipkart.amazon_review_scraper("https://www.flipkart.com/oswaal-cbse-sample-question-paper-class-10-science-for-march-2020-exam/product-reviews/itm2695178aca453?pid=9789389340716&page=1", 1, 1, 100);
scraper = web_scrapper_flipkart.amazon_review_scraper("https://www.flipkart.com/indian-polity-civil-services-other-state-examinations-6th/product-reviews/itm645b5c3212169?pid=9789389538472&page=1", 1, 1, 100);
# scraper = web_scrapper_flipkart.amazon_review_scraper("https://www.flipkart.com/programming-ansi-c-8-e/product-reviews/itme19883f2b5819?pid=9789353165130&page=1", 1, 3, 100);
scraper.scrape()
scraper.write_csv('flipkart1')